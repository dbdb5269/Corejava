package OOAD.homework.six;

/**
 * Created by dubo on 16/10/23.
 */
public class Father  implements Observer{
    public void update() {
        System.out.println("father has received!");
    }
}
