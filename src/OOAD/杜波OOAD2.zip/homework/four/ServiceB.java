package OOAD.homework.four;

/**
 * Created by dubo on 16/10/23.
 */
public class ServiceB {
    public void run(){
        System.out.println("模块B中的run方法");
    }
}
