package OOAD.homework;

/**
 * Created by dubo on 16/10/21.
 */
public class Action {
    public void run(){
        System.out.println("action run");
    }
}

