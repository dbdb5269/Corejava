package OOAD.homework;

/**
 * Created by dubo on 16/10/21.
 */
public interface Work{
    public void doStart();
    public void doRun();
    public void doEnd();
}