package OOAD.homework;

/**
 * Created by dubo on 16/10/21.
 */
public class C {
    public void go(Work work){
        work.doRun();
    }
}
