package OOAD.homework.Two;

/**
 * Created by dubo on 16/10/21.
 */
public class Person implements Action {
    @Override
    public void say(String name){
        System.out.println("hello"+name);
    }




}
