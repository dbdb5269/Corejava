package OOAD.homework.Two;

/**
 * Created by dubo on 16/10/21.
 */
public interface Action {
    public void say(String name);
}
