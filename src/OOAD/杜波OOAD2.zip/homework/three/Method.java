package OOAD.homework.three;

/**
 * Created by dubo on 16/10/23.
 */
interface  Method {

    public void showUsersInfo(Person person);
}
