package OOAD.homework.eight;

/**
 * Created by dubo on 16/10/23.
 */
public interface Handler {
    public void operator();
}
